// Star Rating Functionality - Arabic
const starRating = document.getElementById('starRating');
const ratingText = document.getElementById('ratingText');
const stars = starRating.querySelectorAll('.star');
const radioButtons = starRating.querySelectorAll('input[type="radio"]');

const ratingLabels = {
    1: '⭐ ضعيف',
    2: '⭐⭐ مقبول',
    3: '⭐⭐⭐ جيد',
    4: '⭐⭐⭐⭐ جيد جداً',
    5: '⭐⭐⭐⭐⭐ ممتاز'
};

radioButtons.forEach(radio => {
    radio.addEventListener('change', (e) => {
        const value = e.target.value;
        ratingText.textContent = ratingLabels[value];
        ratingText.classList.add('selected');
    });
});

// Character Counter
const reviewText = document.getElementById('reviewText');
const charCount = document.getElementById('charCount');

reviewText.addEventListener('input', () => {
    const count = reviewText.value.length;
    charCount.textContent = count;
    
    if (count > 900) {
        charCount.style.color = 'var(--warning-color)';
    } else if (count === 1000) {
        charCount.style.color = 'var(--error-color)';
    } else {
        charCount.style.color = 'var(--text-light)';
    }
});

// Photo Upload Functionality
const photoInput = document.getElementById('reviewPhotos');
const photoPreview = document.getElementById('photoPreview');
let uploadedPhotos = [];

photoInput.addEventListener('change', (e) => {
    const files = Array.from(e.target.files);
    
    if (uploadedPhotos.length + files.length > 5) {
        alert('يمكنك تحميل 5 صور كحد أقصى.');
        return;
    }
    
    files.forEach(file => {
        if (file.size > 5 * 1024 * 1024) {
            alert(`${file.name} كبير جداً. الحد الأقصى للحجم هو 5 ميجابايت.`);
            return;
        }
        
        if (!file.type.startsWith('image/')) {
            alert(`${file.name} ليس ملف صورة.`);
            return;
        }
        
        uploadedPhotos.push(file);
        displayPhoto(file);
    });
    
    photoInput.value = '';
});

function displayPhoto(file) {
    const reader = new FileReader();
    
    reader.onload = (e) => {
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        
        const img = document.createElement('img');
        img.src = e.target.result;
        
        const removeBtn = document.createElement('button');
        removeBtn.className = 'photo-remove';
        removeBtn.innerHTML = '×';
        removeBtn.type = 'button';
        removeBtn.onclick = () => removePhoto(file, photoItem);
        
        photoItem.appendChild(img);
        photoItem.appendChild(removeBtn);
        photoPreview.appendChild(photoItem);
    };
    
    reader.readAsDataURL(file);
}

function removePhoto(file, photoItem) {
    uploadedPhotos = uploadedPhotos.filter(f => f !== file);
    photoItem.remove();
}

// Form Submission
const reviewForm = document.getElementById('reviewForm');
const submitBtn = document.getElementById('submitBtn');
const successModal = document.getElementById('successModal');
const modalMessage = document.getElementById('modalMessage');
const modalCloseBtn = document.getElementById('modalCloseBtn');

reviewForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const formData = {
        rating: document.querySelector('input[name="rating"]:checked')?.value,
        userName: document.getElementById('userName').value,
        userEmail: document.getElementById('userEmail').value,
        reviewTitle: document.getElementById('reviewTitle').value,
        reviewText: document.getElementById('reviewText').value,
        photos: uploadedPhotos.length
    };
    
    if (!formData.rating) {
        alert('الرجاء اختيار تقييم بالنجوم.');
        return;
    }
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'جاري الإرسال...';
    
    setTimeout(() => {
        console.log('Review submitted:', formData);
        
        const rating = parseInt(formData.rating);
        
        if (rating <= 3) {
            modalMessage.innerHTML = `
                نأسف لأن تجربتك لم تكن مثالية. 
                <br><br>
                نود تصحيح الأمور! إليك رمز خصم لزيارتك القادمة: 
                <br><br>
                <strong style="font-size: 1.5rem; color: var(--primary-color);">SORRY10</strong>
                <br><br>
                شكراً لك على ملاحظاتك الصادقة!
            `;
            showModal();
        } else {
            modalMessage.innerHTML = `
                شكراً لك على ملاحظاتك الإيجابية! 
                <br><br>
                سيتم توجيهك إلى خرائط جوجل لمشاركة تجربتك.
                <br><br>
                كشكر لك، إليك رمز الخصم الخاص بك: 
                <br>
                <strong style="font-size: 1.5rem; color: var(--primary-color);">THANKS15</strong>
                <br><br>
                <small>إعادة التوجيه خلال <span id="countdown">5</span> ثوانٍ...</small>
            `;
            showModal();
            
            skipRedirectBtn.style.display = 'inline-block';
            
            let countdown = 5;
            const countdownElement = document.getElementById('countdown');
            
            redirectInterval = setInterval(() => {
                countdown--;
                if (countdownElement) {
                    countdownElement.textContent = countdown;
                }
                
                if (countdown <= 0) {
                    clearInterval(redirectInterval);
                    redirectToGoogleMaps();
                }
            }, 1000);
        }
        
        reviewForm.reset();
        uploadedPhotos = [];
        photoPreview.innerHTML = '';
        ratingText.textContent = 'اختر تقييماً';
        ratingText.classList.remove('selected');
        charCount.textContent = '0';
        submitBtn.disabled = false;
        submitBtn.textContent = 'إرسال المراجعة';
    }, 1500);
});

function showModal() {
    successModal.classList.add('active');
}

function hideModal() {
    successModal.classList.remove('active');
}

function redirectToGoogleMaps() {
    const placeId = 'ChIJN1t_tDeuEmsRUsoyG83frY4';
    const googleMapsUrl = `https://search.google.com/local/writereview?placeid=${placeId}`;
    window.location.href = googleMapsUrl;
    console.log('Redirecting to Google Maps:', googleMapsUrl);
}

modalCloseBtn.addEventListener('click', hideModal);

const skipRedirectBtn = document.getElementById('skipRedirectBtn');
let redirectInterval = null;

skipRedirectBtn.addEventListener('click', () => {
    if (redirectInterval) {
        clearInterval(redirectInterval);
    }
    hideModal();
});

successModal.addEventListener('click', (e) => {
    if (e.target === successModal) {
        if (redirectInterval) {
            clearInterval(redirectInterval);
        }
        hideModal();
    }
});

// Form validation feedback
const requiredInputs = document.querySelectorAll('[required]');

requiredInputs.forEach(input => {
    input.addEventListener('blur', () => {
        if (!input.value.trim() && input.type !== 'radio') {
            input.style.borderColor = 'var(--error-color)';
        } else {
            input.style.borderColor = 'var(--border-color)';
        }
    });
    
    input.addEventListener('input', () => {
        if (input.value.trim()) {
            input.style.borderColor = 'var(--success-color)';
        }
    });
});

// Email validation
const emailInput = document.getElementById('userEmail');

emailInput.addEventListener('blur', () => {
    if (emailInput.value && !isValidEmail(emailInput.value)) {
        emailInput.style.borderColor = 'var(--error-color)';
    }
});

function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

console.log('Review page (Arabic) loaded successfully!');
