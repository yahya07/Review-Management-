// Sidebar Navigation
const sidebarLinks = document.querySelectorAll('.sidebar-link');
const cmsSections = document.querySelectorAll('.cms-section');

sidebarLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        sidebarLinks.forEach(l => l.classList.remove('active'));
        cmsSections.forEach(s => s.classList.remove('active'));
        link.classList.add('active');
        const targetId = link.getAttribute('href').substring(1);
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
            targetSection.classList.add('active');
        }
    });
});

// QR Code Generator
let uploadedLogoUrl = null;
let currentQRCodeUrl = null;

const qrForm = document.querySelector('.qr-form');
const qrPreview = document.querySelector('.qr-preview');
const fileInput = document.getElementById('business-logo');
const fileName = document.querySelector('.file-name');

if (fileInput && fileName) {
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            const file = e.target.files[0];
            fileName.textContent = file.name;
            const reader = new FileReader();
            reader.onload = (event) => {
                uploadedLogoUrl = event.target.result;
            };
            reader.readAsDataURL(file);
        } else {
            fileName.textContent = 'No file chosen';
            uploadedLogoUrl = null;
        }
    });
}

if (qrForm) {
    qrForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const locationName = document.getElementById('location-name').value;
        const websiteUrl = document.getElementById('website-url').value;
        const qrSize = document.getElementById('qr-size').value;
        const qrColor = document.getElementById('qr-color').value.replace('#', '');
        const qrBgColor = document.getElementById('qr-bg-color').value;
        
        if (!locationName || !websiteUrl) {
            alert('Please enter both location name and website URL');
            return;
        }
        generateQRCode(websiteUrl, qrSize, qrColor, qrBgColor, locationName);
    });
}

function generateQRCode(url, size, color, bgColor, locationName) {
    const qrInfo = document.querySelector('.qr-info');
    qrPreview.innerHTML = '<div class="qr-placeholder"><p>Generating QR Code...</p></div>';
    
    const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url)}&color=${color}&bgcolor=${bgColor}`;
    currentQRCodeUrl = apiUrl;
    
    const logoHtml = uploadedLogoUrl 
        ? `<img src="${uploadedLogoUrl}" alt="Logo" style="width: 70px; height: 70px; object-fit: contain; margin-bottom: 12px; border-radius: 8px; background: white; padding: 5px;">` 
        : '';
    
    qrPreview.innerHTML = `
        <div style="background: white; border: 3px solid #${color}; border-radius: 12px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <div style="color: #${color}; font-weight: bold; font-size: 16px; text-align: center; margin-bottom: 12px;">${locationName}</div>
            ${logoHtml}
            <img src="${apiUrl}" alt="QR Code" style="width: ${Math.min(parseInt(size), 300)}px; height: ${Math.min(parseInt(size), 300)}px; margin-bottom: 12px;" id="generated-qr-image">
            <div style="color: #fbbf24; font-size: 24px; letter-spacing: 2px;">⭐⭐⭐⭐⭐</div>
        </div>
    `;
    
    document.getElementById('download-png').disabled = false;
    document.getElementById('copy-clipboard').disabled = false;
    document.getElementById('print-qr').disabled = false;
    
    if (qrInfo) {
        qrInfo.style.display = 'block';
        document.getElementById('info-url').textContent = url;
        document.getElementById('info-size').textContent = `${size}x${size}px`;
        document.getElementById('info-date').textContent = new Date().toLocaleString();
    }
    alert(`QR Code generated successfully for "${locationName}"!`);
}

const downloadBtn = document.getElementById('download-png');
const copyBtn = document.getElementById('copy-clipboard');
const printBtn = document.getElementById('print-qr');

if (downloadBtn) {
    downloadBtn.addEventListener('click', () => {
        const qrImage = document.getElementById('generated-qr-image');
        const locationName = document.getElementById('location-name')?.value || 'QRCode';
        if (qrImage) {
            const link = document.createElement('a');
            link.href = qrImage.src;
            link.download = `${locationName.replace(/\s+/g, '-')}-QRCode.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            alert(`Downloading QR code for "${locationName}"...`);
        }
    });
}

if (copyBtn) {
    copyBtn.addEventListener('click', () => {
        const qrImage = document.getElementById('generated-qr-image');
        if (qrImage) {
            fetch(qrImage.src)
                .then(res => res.blob())
                .then(blob => {
                    const item = new ClipboardItem({ 'image/png': blob });
                    return navigator.clipboard.write([item]);
                })
                .then(() => alert('QR Code copied to clipboard!'))
                .catch(() => {
                    const websiteUrl = document.getElementById('website-url').value;
                    navigator.clipboard.writeText(websiteUrl).then(() => {
                        alert('QR Code URL copied to clipboard!');
                    }).catch(() => {
                        alert('Unable to copy. Please try downloading instead.');
                    });
                });
        }
    });
}

if (printBtn) {
    printBtn.addEventListener('click', () => {
        if (qrPreview) {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html><head><title>Print QR Code</title>
                <style>body{display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;font-family:Arial,sans-serif;}</style>
                </head><body><div>${qrPreview.innerHTML}</div></body></html>
            `);
            printWindow.document.close();
            setTimeout(() => printWindow.print(), 250);
        }
    });
}

// Feedback Management
const feedbackItems = document.querySelectorAll('.feedback-item');
feedbackItems.forEach(item => {
    const buttons = item.querySelectorAll('.feedback-actions .btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            const action = btn.textContent.trim();
            if (action.includes('Apology') || action.includes('Response')) {
                alert('Sending response with discount code...');
                item.style.opacity = '0.5';
            } else if (action.includes('Resolved')) {
                item.style.display = 'none';
                alert('Feedback marked as resolved.');
            }
        });
    });
});

// Template Forms
const templateForms = document.querySelectorAll('.template-form');
templateForms.forEach(form => {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Template saved successfully!');
    });
});

// Offer Form
const offerForm = document.querySelector('.offer-form');
if (offerForm) {
    offerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const offerName = document.getElementById('offer-name').value;
        const offerCode = document.getElementById('offer-code').value;
        alert(`Offer "${offerName}" created with code: ${offerCode}`);
        offerForm.reset();
    });
}

// Offer Card Actions
const offerCards = document.querySelectorAll('.offer-card');
offerCards.forEach(card => {
    const buttons = card.querySelectorAll('.offer-actions .btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            const action = btn.textContent.trim();
            const offerName = card.querySelector('h4').textContent;
            if (action === 'Edit') {
                alert(`Editing offer: ${offerName}`);
            } else if (action === 'Deactivate') {
                if (confirm(`Are you sure you want to deactivate "${offerName}"?`)) {
                    card.style.opacity = '0.5';
                    alert('Offer deactivated.');
                }
            }
        });
    });
});

// QR Code Card Actions
const qrCodeCards = document.querySelectorAll('.qr-code-card');
qrCodeCards.forEach(card => {
    const buttons = card.querySelectorAll('.btn-icon');
    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            const title = btn.getAttribute('title');
            const locationName = card.querySelector('h4').textContent;
            if (title === 'Download') {
                alert(`Downloading QR code for ${locationName}`);
            } else if (title === 'Edit') {
                alert(`Editing QR code for ${locationName}`);
            } else if (title === 'Delete') {
                if (confirm(`Are you sure you want to delete the QR code for ${locationName}?`)) {
                    card.style.display = 'none';
                    alert('QR code deleted.');
                }
            }
        });
    });
});

// Settings Forms
const settingsForms = document.querySelectorAll('.settings-form');
settingsForms.forEach(form => {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Settings saved successfully!');
    });
});

// Period Selector for Analytics
const periodSelector = document.querySelector('.period-selector');
if (periodSelector) {
    periodSelector.addEventListener('change', (e) => {
        const period = e.target.value;
        console.log(`Loading analytics for: ${period}`);
        alert(`Loading analytics for: ${period}`);
    });
}

// Logout Button
const logoutBtn = document.querySelector('.btn-logout');
if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to logout?')) {
            alert('Logging out...');
            window.location.href = 'index.html';
        }
    });
}

// Animate metrics on page load
const animateMetrics = () => {
    const metricValues = document.querySelectorAll('.metric-value');
    metricValues.forEach(metric => {
        const text = metric.textContent;
        const number = parseFloat(text);
        if (!isNaN(number)) {
            let current = 0;
            const increment = number / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= number) {
                    current = number;
                    clearInterval(timer);
                }
                if (text.includes('.')) {
                    metric.innerHTML = current.toFixed(1) + (metric.querySelector('.metric-unit')?.outerHTML || '');
                } else {
                    metric.innerHTML = Math.floor(current) + (metric.querySelector('.metric-unit')?.outerHTML || '');
                }
            }, 20);
        }
    });
};

if (document.getElementById('overview')?.classList.contains('active')) {
    setTimeout(animateMetrics, 300);
}

console.log('CMS Dashboard loaded successfully!');
