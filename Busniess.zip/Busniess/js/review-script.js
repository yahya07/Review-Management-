// Star Rating Functionality
const starRating = document.getElementById('starRating');
const ratingText = document.getElementById('ratingText');
const stars = starRating.querySelectorAll('.star');
const radioButtons = starRating.querySelectorAll('input[type="radio"]');

const ratingLabels = {
    1: '⭐ Poor',
    2: '⭐⭐ Fair',
    3: '⭐⭐⭐ Good',
    4: '⭐⭐⭐⭐ Very Good',
    5: '⭐⭐⭐⭐⭐ Excellent'
};

radioButtons.forEach(radio => {
    radio.addEventListener('change', (e) => {
        const value = e.target.value;
        ratingText.textContent = ratingLabels[value];
        ratingText.classList.add('selected');
    });
});

// Character Counter
const reviewText = document.getElementById('reviewText');
const charCount = document.getElementById('charCount');

reviewText.addEventListener('input', () => {
    const count = reviewText.value.length;
    charCount.textContent = count;
    
    if (count > 900) {
        charCount.style.color = 'var(--warning-color)';
    } else if (count === 1000) {
        charCount.style.color = 'var(--error-color)';
    } else {
        charCount.style.color = 'var(--text-light)';
    }
});

// Photo Upload Functionality
const photoInput = document.getElementById('reviewPhotos');
const photoPreview = document.getElementById('photoPreview');
let uploadedPhotos = [];

photoInput.addEventListener('change', (e) => {
    const files = Array.from(e.target.files);
    
    // Limit to 5 photos
    if (uploadedPhotos.length + files.length > 5) {
        alert('You can upload a maximum of 5 photos.');
        return;
    }
    
    files.forEach(file => {
        // Check file size (5MB max)
        if (file.size > 5 * 1024 * 1024) {
            alert(`${file.name} is too large. Maximum size is 5MB.`);
            return;
        }
        
        // Check file type
        if (!file.type.startsWith('image/')) {
            alert(`${file.name} is not an image file.`);
            return;
        }
        
        uploadedPhotos.push(file);
        displayPhoto(file);
    });
    
    // Reset input
    photoInput.value = '';
});

function displayPhoto(file) {
    const reader = new FileReader();
    
    reader.onload = (e) => {
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        
        const img = document.createElement('img');
        img.src = e.target.result;
        
        const removeBtn = document.createElement('button');
        removeBtn.className = 'photo-remove';
        removeBtn.innerHTML = '×';
        removeBtn.type = 'button';
        removeBtn.onclick = () => removePhoto(file, photoItem);
        
        photoItem.appendChild(img);
        photoItem.appendChild(removeBtn);
        photoPreview.appendChild(photoItem);
    };
    
    reader.readAsDataURL(file);
}

function removePhoto(file, photoItem) {
    uploadedPhotos = uploadedPhotos.filter(f => f !== file);
    photoItem.remove();
}

// Form Submission
const reviewForm = document.getElementById('reviewForm');
const submitBtn = document.getElementById('submitBtn');
const successModal = document.getElementById('successModal');
const modalMessage = document.getElementById('modalMessage');
const modalCloseBtn = document.getElementById('modalCloseBtn');

reviewForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Get form data
    const formData = {
        rating: document.querySelector('input[name="rating"]:checked')?.value,
        userName: document.getElementById('userName').value,
        userEmail: document.getElementById('userEmail').value,
        reviewTitle: document.getElementById('reviewTitle').value,
        reviewText: document.getElementById('reviewText').value,
        photos: uploadedPhotos.length
    };
    
    // Validate rating
    if (!formData.rating) {
        alert('Please select a star rating.');
        return;
    }
    
    // Show loading state
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting...';
    
    // Simulate API call
    setTimeout(() => {
        console.log('Review submitted:', formData);
        
        // Determine routing based on rating
        const rating = parseInt(formData.rating);
        
        if (rating <= 3) {
            // Low rating - show apology and discount
            modalMessage.innerHTML = `
                We're sorry your experience wasn't perfect. 
                <br><br>
                We'd love to make it right! Here's a discount code for your next visit: 
                <br><br>
                <strong style="font-size: 1.5rem; color: var(--primary-color);">SORRY10</strong>
                <br><br>
                Thank you for your honest feedback!
            `;
            showModal();
        } else {
            // High rating - encourage Google review and redirect
            modalMessage.innerHTML = `
                Thank you for your positive feedback! 
                <br><br>
                You'll be redirected to Google Maps to share your experience.
                <br><br>
                As a thank you, here's your discount code: 
                <br>
                <strong style="font-size: 1.5rem; color: var(--primary-color);">THANKS15</strong>
                <br><br>
                <small>Redirecting in <span id="countdown">5</span> seconds...</small>
            `;
            showModal();
            
            // Show skip button
            skipRedirectBtn.style.display = 'inline-block';
            
            // Countdown and redirect to Google Maps
            let countdown = 5;
            const countdownElement = document.getElementById('countdown');
            
            redirectInterval = setInterval(() => {
                countdown--;
                if (countdownElement) {
                    countdownElement.textContent = countdown;
                }
                
                if (countdown <= 0) {
                    clearInterval(redirectInterval);
                    redirectToGoogleMaps();
                }
            }, 1000);
        }
        
        // Reset form
        reviewForm.reset();
        uploadedPhotos = [];
        photoPreview.innerHTML = '';
        ratingText.textContent = 'Select a rating';
        ratingText.classList.remove('selected');
        charCount.textContent = '0';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Review';
    }, 1500);
});

function showModal() {
    successModal.classList.add('active');
}

function hideModal() {
    successModal.classList.remove('active');
}

function redirectToGoogleMaps() {
    // ============================================
    // CONFIGURATION: Set your Google Place ID here
    // ============================================
    // To find your Place ID:
    // 1. Go to https://developers.google.com/maps/documentation/places/web-service/place-id
    // 2. Search for your business
    // 3. Copy the Place ID
    
    // REPLACE THIS with your actual business Place ID
    const placeId = 'ChIJN1t_tDeuEmsRUsoyG83frY4'; // Example: Google Sydney
    
    // Alternative configuration (if you don't have Place ID)
    const businessName = 'Bellas Bistro';
    const businessLocation = 'Downtown';
    
    // ============================================
    // Method 1: Using Place ID (RECOMMENDED)
    // This directly opens the review page for your business
    // ============================================
    const googleMapsUrl = `https://search.google.com/local/writereview?placeid=${placeId}`;
    
    // ============================================
    // Method 2: Using search query (FALLBACK)
    // Uncomment this if you don't have a Place ID
    // This opens Google Maps search, user needs to find your business
    // ============================================
    // const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(businessName + ' ' + businessLocation)}`;
    
    // Redirect to Google Maps
    window.location.href = googleMapsUrl;
    
    console.log('Redirecting to Google Maps:', googleMapsUrl);
}

modalCloseBtn.addEventListener('click', hideModal);

const skipRedirectBtn = document.getElementById('skipRedirectBtn');
let redirectInterval = null;

skipRedirectBtn.addEventListener('click', () => {
    if (redirectInterval) {
        clearInterval(redirectInterval);
    }
    hideModal();
});

successModal.addEventListener('click', (e) => {
    if (e.target === successModal) {
        if (redirectInterval) {
            clearInterval(redirectInterval);
        }
        hideModal();
    }
});

// Form validation feedback
const requiredInputs = document.querySelectorAll('[required]');

requiredInputs.forEach(input => {
    input.addEventListener('blur', () => {
        if (!input.value.trim() && input.type !== 'radio') {
            input.style.borderColor = 'var(--error-color)';
        } else {
            input.style.borderColor = 'var(--border-color)';
        }
    });
    
    input.addEventListener('input', () => {
        if (input.value.trim()) {
            input.style.borderColor = 'var(--success-color)';
        }
    });
});

// Email validation
const emailInput = document.getElementById('userEmail');

emailInput.addEventListener('blur', () => {
    if (emailInput.value && !isValidEmail(emailInput.value)) {
        emailInput.style.borderColor = 'var(--error-color)';
    }
});

function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

console.log('Review page loaded successfully!');
