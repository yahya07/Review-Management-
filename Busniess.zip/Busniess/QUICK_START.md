# Quick Start Guide

## 🚀 Getting Started

### 1. Open the Website
Simply open `index.html` in your web browser. No installation or build process required!

### 2. Navigate the Site

#### Main Pages:
- **Landing Page**: `index.html` (English) or `pages/ar/index-ar.html` (Arabic)
- **CMS Dashboard**: `pages/cms.html`
- **Review Page**: `pages/review.html` (English) or `pages/ar/review-ar.html` (Arabic)

#### Language Switching:
- Use the language switcher in the navigation bar (EN/AR)
- Automatically switches between English and Arabic versions

### 3. Customize Your Business

#### Update Business Information:
1. Open `pages/review.html` and `pages/ar/review-ar.html`
2. Change the business name and location in the header section
3. Update the logo placeholder

#### Configure Google Maps Integration:
1. Open `js/review-script.js` and `js/review-script-ar.js`
2. Find the `redirectToGoogleMaps()` function
3. Replace the `placeId` with your Google Place ID
4. Instructions are in the comments

#### Customize Colors and Branding:
1. Open `css/styles.css`
2. Edit the CSS variables in the `:root` section:
```css
:root {
    --primary-color: #6366f1;
    --primary-dark: #4f46e5;
    --secondary-color: #8b5cf6;
    /* ... more variables */
}
```

#### Adjust Discount Codes:
1. Open `js/review-script.js` and `js/review-script-ar.js`
2. Find the form submission section
3. Change `SORRY10` and `THANKS15` to your preferred codes

### 4. Deploy

#### Option 1: Simple Hosting
Upload all files to any web hosting service:
- Netlify (drag & drop)
- Vercel
- GitHub Pages
- Traditional web hosting

#### Option 2: Local Testing
Just open `index.html` in your browser - it works offline!

## 📁 File Organization

```
Your Project/
├── index.html              ← Start here
├── css/                    ← All styles
├── js/                     ← All scripts
├── pages/                  ← Additional pages
│   ├── cms.html
│   ├── review.html
│   └── ar/                 ← Arabic versions
└── assets/                 ← Your images/logos
```

## 🎨 Customization Checklist

- [ ] Update business name in all pages
- [ ] Replace logo placeholder with your logo
- [ ] Configure Google Place ID
- [ ] Customize discount codes
- [ ] Adjust brand colors
- [ ] Update contact information
- [ ] Add your business locations to CMS
- [ ] Test QR code generation
- [ ] Test review submission flow

## 🌐 Language Support

The website is fully bilingual:
- **English**: Default pages
- **Arabic**: Pages in `/pages/ar/` folder
- RTL (Right-to-Left) support included
- Easy language switching

## 📱 Mobile Responsive

All pages are fully responsive and work on:
- Desktop computers
- Tablets
- Mobile phones

## 🔧 Technical Requirements

- Modern web browser (Chrome, Firefox, Safari, Edge)
- No server-side requirements
- No build tools needed
- Pure HTML/CSS/JavaScript

## 💡 Tips

1. **Test locally first**: Open files in your browser before deploying
2. **Use browser dev tools**: Press F12 to debug any issues
3. **Check console**: Look for any JavaScript errors
4. **Mobile testing**: Use browser's device emulation mode

## 🆘 Need Help?

Check the main `README.md` for detailed documentation about:
- Features overview
- CMS functionality
- Review system workflow
- Analytics and insights

## 🎯 Next Steps

1. Customize the content
2. Add your branding
3. Configure Google Maps
4. Generate QR codes
5. Test the review flow
6. Deploy to production

Happy reviewing! 🌟
